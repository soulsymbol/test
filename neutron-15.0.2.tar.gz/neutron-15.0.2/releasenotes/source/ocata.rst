===================================
 Ocata Series Release Notes
===================================

.. release-notes::
   :branch: stable/ocata
   :ignore-notes:
       deprecate-SRIOV-physical_device_mappings-67dd3317181eb513
