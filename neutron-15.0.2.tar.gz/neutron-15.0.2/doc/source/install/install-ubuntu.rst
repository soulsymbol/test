.. _networking-ubuntu:

================================
Install and configure for Ubuntu
================================

.. toctree::
   :maxdepth: 2

   environment-networking-ubuntu.rst
   controller-install-ubuntu.rst
   compute-install-ubuntu.rst
   verify.rst
