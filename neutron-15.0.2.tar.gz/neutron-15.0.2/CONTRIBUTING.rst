If you would like to contribute to the development of OpenStack Networking,
you must follow the steps documented at:

   https://docs.openstack.org/neutron/latest/contributor/policies/blueprints.html

Pull requests submitted through GitHub will be ignored.

Bugs should be filed on Launchpad, not GitHub:

   https://bugs.launchpad.net/neutron

Please: do not register blueprints, they will be marked *obsolete* and ignored.
