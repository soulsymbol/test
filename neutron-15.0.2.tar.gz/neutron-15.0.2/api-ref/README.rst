Networking API reference is maintained in the neutron-lib repo.
See api-ref in the neutron-lib repository.
